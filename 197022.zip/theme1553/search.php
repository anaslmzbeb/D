<?php get_header(); ?>
<div id="content" class="grid_8 <?php if (of_get_option('blog_sidebar_pos') == "right" ) {echo "alpha";} else {echo "omega";} ?> <?php echo of_get_option('blog_sidebar_pos') ?>">
	<div class="content-box">

  <div class="header-title"><h2>Search for: <b>"<?php the_search_query(); ?>"</b></h2></div>
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class('post-holder'); ?>>
      
        <?php $post_image_size = of_get_option('post_image_size'); ?>
				<?php if($post_image_size=='' || $post_image_size=='normal'){ ?>
          <?php if(has_post_thumbnail()) {
            echo '<figure class="featured-thumbnail"><span class="img-wrap"><a href="'; the_permalink(); echo '">';
            echo the_post_thumbnail();
            echo '</a></span></figure>';
            }
          ?>
        <?php } else { ?>
          <?php if(has_post_thumbnail()) {
            echo '<figure class="featured-thumbnail large"><span class="img-wrap clearfix"><span class="f-thumb-wrap"><a href="'; the_permalink(); echo '">';
            echo the_post_thumbnail('post-thumbnail-xl');
            echo '</a></span></span></figure>';
            }
          ?>
        <?php } ?>
        
         <div class="post-header">
            <h5><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
				<?php $post_meta = of_get_option('post_meta'); ?>
            <?php if ($post_meta=='true' || $post_meta=='') { ?>
               <div class="post-meta">
               <?php _e('by', 'theme1553'); ?> <?php the_author_posts_link() ?> <?php _e('on', 'theme1553'); ?> <time datetime="<?php the_time('Y-m-d\TH:i'); ?>"><?php the_time('d/m/Y'); ?></time> <?php _e('with', 'theme1553'); ?> <?php comments_popup_link('0 comments', '1 comment', '% comments', 'comments-link', 'closed comments'); ?>
               </div><!--.post-meta-->
            <?php } ?>		
         </div>
        
        
        <div class="post-content">
          <?php $post_excerpt = of_get_option('post_excerpt'); ?>
      		<?php if ($post_excerpt=='true' || $post_excerpt=='') { ?>
            <div class="excerpt"><?php $excerpt = get_the_excerpt(); echo my_string_limit_words($excerpt,45);?></div>
          <?php } ?>
        </div>
        
          <a href="<?php the_permalink() ?>" class="link"><?php _e('Read More', 'theme1553'); ?></a>
        
    </article>

  <?php endwhile; else: ?>
    <div class="no-results">
    	<?php echo '<h2>' . __('No Results', 'theme1553') . '</h2>'; ?>
      <?php echo '<p>' . __('Please feel free try again!', 'theme1553') . '</p>'; ?>
      <?php get_search_form(); ?> <!-- outputs the default Wordpress search form-->
    </div><!--noResults-->
  <?php endif; ?>

    <?php if(function_exists('wp_pagenavi')) : ?>
			<?php wp_pagenavi(); ?>
    <?php else : ?>
      <?php if ( $wp_query->max_num_pages > 1 ) : ?>
        <nav class="oldernewer">
          <div class="older">
            <?php next_posts_link( __('&laquo; Older Entries', 'theme1553')) ?>
          </div><!--.older-->
          <div class="newer">
            <?php previous_posts_link(__('Newer Entries &raquo;', 'theme1553')) ?>
          </div><!--.newer-->
        </nav><!--.oldernewer-->
      <?php endif; ?>
    <?php endif; ?>
    <!-- Page navigation -->

	</div>
</div><!-- #content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>