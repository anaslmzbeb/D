<?php
/**
 * Template Name: Home Page
 */

get_header(); ?>

	<div class="grid_3 alpha">
		<?php if ( ! dynamic_sidebar( 'Content Area 1' ) ) : ?>
         <!--Widgetized Content-->
      <?php endif ?>
   </div>
   
   <div class="grid_3">
		<?php if ( ! dynamic_sidebar( 'Content Area 2' ) ) : ?>
         <!--Widgetized Content-->
      <?php endif ?>
   </div>
   
   <div class="grid_3">
		<?php if ( ! dynamic_sidebar( 'Content Area 3' ) ) : ?>
         <!--Widgetized Content-->
      <?php endif ?>
   </div>
   
   <div class="grid_3 omega">
		<?php if ( ! dynamic_sidebar( 'Content Area 4' ) ) : ?>
         <!--Widgetized Content-->
      <?php endif ?>
   </div>

<?php get_footer(); ?>