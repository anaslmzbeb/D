				</div>
         </div>
      </div>
   </div>
	
   <footer id="footer">
		<div class="container_12 clearfix">
         <div class="grid_12">
         
         
            <div class="footer-widget-area">
            	
               <div class="grid_3 alpha">
						<?php if ( ! dynamic_sidebar( 'Footer Area 1' ) ) : ?>
                     <!--Widgetized Footer-->
                  <?php endif ?>
               </div>
               
               <div class="grid_3">
						<?php if ( ! dynamic_sidebar( 'Footer Area 2' ) ) : ?>
                     <!--Widgetized Footer-->
                  <?php endif ?>
               </div>
               
               <div class="grid_3">
						<?php if ( ! dynamic_sidebar( 'Footer Area 3' ) ) : ?>
                     <!--Widgetized Footer-->
                  <?php endif ?>
               </div>
               
               <div class="grid_3 omega">
						<?php if ( ! dynamic_sidebar( 'Footer Area 4' ) ) : ?>
                     <!--Widgetized Footer-->
                  <?php endif ?>
               </div>
               
            </div>
      		
            
            <div class="footer-block">
            
					<?php if ( of_get_option('footer_menu') == 'true') { ?>  
                  <nav class="footer">
							<?php wp_nav_menu( array(
								'container'       => 'ul', 
								'menu_class'      => 'footer-nav', 
								'depth'           => 0,
								'theme_location' => 'footer_menu' 
                       )); 
                     ?>
                  </nav>
               <?php } ?>
               
               <div id="footer-text">
						<?php $myfooter_text = of_get_option('footer_text'); ?>
                  <?php if($myfooter_text){?>
							<?php echo of_get_option('footer_text'); ?>
                  <?php } else { ?>
                     <a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>" class="site-name"><?php bloginfo('name'); ?></a> <?php _e('is proudly powered by', 'theme1553'); ?> <a href="http://wordpress.org">WordPress</a> <a href="<?php if ( of_get_option('feed_url') != '' ) { echo of_get_option('feed_url'); } else bloginfo('rss2_url'); ?>" rel="nofollow" title="<?php _e('Entries (RSS)', 'theme1553'); ?>"><?php _e('Entries (RSS)', 'theme1553'); ?></a> and <a href="<?php bloginfo('comments_rss2_url'); ?>" rel="nofollow"><?php _e('Comments (RSS)', 'theme1553'); ?></a> <?php if( is_front_page() ) { ?><!-- {%FOOTER_LINK} --><?php } ?>
                  <?php } ?>
               </div>
            
            </div>
					
               
         </div>
		</div>
	</footer>
   
</div><!--#main-->
<?php wp_footer(); ?> <!-- this is used by many Wordpress features and for plugins to work properly -->
<?php if(of_get_option('ga_code')) { ?>
	<script type="text/javascript">
		<?php echo stripslashes(of_get_option('ga_code')); ?>
	</script>
  <!-- Show Google Analytics -->	
<?php } ?>
</body>
</html>